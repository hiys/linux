<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: space.php 9626 2010-04-30 07:19:36Z zhengqingpeng $
 */

$_GET['mod'] = 'space';
require_once 'home.php';
?>
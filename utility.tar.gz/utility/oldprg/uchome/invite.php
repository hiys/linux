<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: invite.php 9625 2010-04-30 07:18:56Z zhengqingpeng $
 */

$_GET['mod'] = 'invite';
require_once 'home.php';
?>
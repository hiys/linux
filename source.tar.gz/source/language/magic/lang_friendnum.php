<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_friendnum.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'friendnum_name' => '好友增容卡',
	'friendnum_desc' => '增加好友容量上限',
	'friendnum_info' => '额外增加 {num} 个好友上限',
	'friendnum_addnum' => '增加好友数',
);

?>
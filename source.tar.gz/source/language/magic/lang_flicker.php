<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_flicker.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$lang = array
(
	'flicker_name' => '彩虹炫',
	'flicker_desc' => '在日志、相册评论中使用彩虹炫',
	'flicker_info' => '在日志、相册评论中使用彩虹炫',
	'flicker_succeed' => '彩虹炫使用成功。',
);